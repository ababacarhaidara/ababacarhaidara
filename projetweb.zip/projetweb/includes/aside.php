		<aside>
					<div class="wrapper">
						<div class="column-1">
							<div class="box">
								<div class="aligncenter">
									<h4>Ventes des terrains</h4>
								</div>
								<div class="box-bg maxheight">
									<div class="padding">
										<h6 class="color-1">Nous avons des terrains à vendre à Missertté, Calavi, Vakon</h6>
										<p> Manisfestez vous ceux qui sont interessés</p>
									</div>
									<div class="aligncenter">
										<a class="button" href="#">plus de details</a>
									</div>
								</div>
							</div>
						</div>
						<div class="column-1">
							<div class="box">
								<div class="aligncenter">
									<h4>Location des maisons</h4>
								</div>
								<div class="box-bg maxheight">
									<div class="padding">
										<h6 class="color-1">Des appartemments sont disponibles à Porto et à Cotonou</h6>
										<p>Vos problèmes des maisons sont finis avec ImmobPorto.<br> Si vous avez de maison à louer, mettez les à notre à disposition </p>
									</div>
									<div class="aligncenter">
										<a class="button" href="#">plus de details</a>
									</div>
								</div>
							</div>
						</div>
						<div class="column-2">
							<div class="box">
								<div class="aligncenter">
									<h4>Location des meubles</h4>
								</div>
								<div class="box-bg maxheight">
									<div class="padding">
										<h6 class="color-1">Pour vos besoins de meubles, nous sommmes un leader</h6>
										<p> Faites un tour dans notre Espace, vous ne regretterez pas</p>
									</div>
									<div class="aligncenter">
										<a class="button" href="#">plus de details</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</aside>