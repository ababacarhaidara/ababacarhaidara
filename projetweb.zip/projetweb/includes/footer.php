<footer>
			<div class="main">
				<div class="footer-bg">
					<p class="prev-indent-bot">ImmobPorto<a class="link" href="http://store.templatemonster.com?aff=netsib1" target="_blank" rel="nofollow"> created by licence informatique IMSP 2021</a></p>
					<ul class="list-services">
						<li><a class="tooltips" title="facebook"></a></li>
						<li class="item-1"><a class="tooltips" title="twitter"></a></li>
						<li class="item-2"><a class="tooltips" title="linkedin"></a></li>
					</ul>
				</div>
			</div>
		</footer>