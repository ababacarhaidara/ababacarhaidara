             
<div class="wrapper">

             <div class="slider">
							<ul class="items">
								<li><img src="images/slider-img1.jpg" alt="" /></li>
								<li><img src="images/slider-img2.jpg" alt="" /></li>
								<li><img src="images/slider-img3.jpg" alt="" /></li>
							</ul> 
			</div>
</div>