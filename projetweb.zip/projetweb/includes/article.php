<section id="content">
					<div class="wrapper">
						<article class="col-1">
							<div class="indent-left">
								<h2>Bienvenue sur notre plate forme</h2>
								<h6 class="prev-indent-bot">ImmobPorto <a class="color-2">est une plate forme</a> crée par un etudiant de la licence informatique IMSP 2021 </h6>
								<p class="prev-indent-bot">ImmobPorto est une plate forme qui fait la promotion des ventes des terrains, location des maisons et des mobiliers.</p>
								
							</div>
						</article>
						<article class="col-2">
							<h3>Notre Staff</h3>
							<div class="wrapper indent-bot">
								<figure class="img-indent"><img src="images/page1-img1.jpg" alt="" /></figure>
								<div class="extra-wrap text-1">
									<div class="margin-top">
										<h6><a class="link color-2"> Directeur Géeneral</a></h6>
										M.Jean PABLO, diplomé d'un master en manangemment de projet.
									</div>
								</div>
							</div>
							<div class="wrapper">
								<figure class="img-indent"><img src="images/page1-img2.jpg" alt="" /></figure>
								<div class="extra-wrap text-1">
									<div class="margin-top">
										<h6><a class="link color-2"> Chef Comptable</a></h6>
										M.Bal ABY, diplomé d'une maitrise en finances et comptablité, membre de l'association des professionnels de la comptabilité.
									</div>
								</div>
							</div>
						</article>
					</div>
					<div class="block"></div>
				</section>
			</div>
		</div>